package com.urdomain.ch08;

public class RemoteControlExample2 {
	public static void main(String[] args) {
		RemoteControl rc = new RemoteControl() {
			public void turnOn() { /*���๮*/ }
			public void turnOff() { /*���๮*/ }
			public void setVolume(int volume) { /*���๮*/ }
		};
	}
}

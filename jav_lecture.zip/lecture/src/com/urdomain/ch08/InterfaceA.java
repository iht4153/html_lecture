package com.urdomain.ch08;

public interface InterfaceA {
	public void methodA();
}

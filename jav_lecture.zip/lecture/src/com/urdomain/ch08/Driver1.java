package com.urdomain.ch08;

import com.urdomain.ch07.Vehicle;

public class Driver1 {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}
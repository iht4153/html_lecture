package com.urdomain.ch08;

public interface ChildInterface1 extends ParentInterface {
	public void method3();
}

package com.urdomain.ch08;

public interface InterfaceC extends InterfaceA, InterfaceB {
	public void methodC();
}

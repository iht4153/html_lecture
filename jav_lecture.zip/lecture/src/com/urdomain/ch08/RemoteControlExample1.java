package com.urdomain.ch08;

public class RemoteControlExample1 {
	public static void main(String[] args) {
		RemoteControl rc;
		rc = new Television();
		rc = new Audio();
	}
}

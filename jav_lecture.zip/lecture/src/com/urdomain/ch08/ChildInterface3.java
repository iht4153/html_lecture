package com.urdomain.ch08;

public interface ChildInterface3 extends ParentInterface {
	@Override
	public void method2();	//�߻� �޼ҵ�� �缱��
	public void method3();
}

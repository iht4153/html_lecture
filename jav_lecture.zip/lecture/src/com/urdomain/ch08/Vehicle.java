package com.urdomain.ch08;

public interface Vehicle {
	public void run();
}

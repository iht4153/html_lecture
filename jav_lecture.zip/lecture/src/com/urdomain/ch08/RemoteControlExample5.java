package com.urdomain.ch08;

public class RemoteControlExample5 {
	public static void main(String[] args) {
		RemoteControl.changeBattery();
	}
}

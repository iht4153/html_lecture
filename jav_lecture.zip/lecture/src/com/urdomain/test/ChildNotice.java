package com.urdomain.test;

public class ChildNotice {

}

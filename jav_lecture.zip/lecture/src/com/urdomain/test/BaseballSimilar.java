package com.urdomain.test;

public class BaseballSimilar {
	public static void main(String[] args) {
		String menu;
		String display;
		
	}
}

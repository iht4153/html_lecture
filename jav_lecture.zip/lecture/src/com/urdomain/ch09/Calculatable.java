package com.urdomain.ch09;

public interface Calculatable {
	public int sum();
}

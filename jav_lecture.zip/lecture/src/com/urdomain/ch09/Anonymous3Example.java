package com.urdomain.ch09;

public class Anonymous3Example {
	public static void main(String[] args) {
		Anonymous3 anony = new Anonymous3();
		anony.method(0, 0);
	}
}

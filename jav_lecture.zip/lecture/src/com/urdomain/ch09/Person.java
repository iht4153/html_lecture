package com.urdomain.ch09;

public class Person {
	void wake() {
		System.out.println("7�ÿ� �Ͼ�ϴ�.");
	}
	
	public Person() {}
	
	public Person(String _str) {}
	
}

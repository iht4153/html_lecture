package com.urdomain.ch09;

public class Main2 {
	public static void main(String[] args) {
		Window w = new Window();
		w.button1.touch();
		w.button2.touch();
	}
}

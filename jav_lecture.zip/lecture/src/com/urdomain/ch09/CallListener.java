package com.urdomain.ch09;

public class CallListener implements Button1.OnClickListener {
	@Override
	public void onClick() {
		System.out.println("��ȭ�� �̴ϴ�.");
	}
}

package com.urdomain.ch09;

public interface RemoteControl {
	public void turnOn();
	public void turnOff();
}

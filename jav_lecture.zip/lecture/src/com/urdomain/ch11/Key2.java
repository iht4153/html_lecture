package com.urdomain.ch11;

public class Key2 {
	
	@Override
	public int hashCode() {
		return number;
	}
}

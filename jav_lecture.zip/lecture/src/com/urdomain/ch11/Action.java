package com.urdomain.ch11;

public interface Action {
	public void execute();
}

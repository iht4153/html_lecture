package com.urdomain.ch01;

public class Hello {
	public static void main(String[] args) {
		System.out.println("Hello, welcome to the java World!");
	}
		
//	public double aa(int bbb) {
//		System.out.println("###" + bbb);
//		double a = 1;
//		a = a + bbb;
//		
//		a = bbb;
//		return a; 
//	}
}
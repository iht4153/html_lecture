package com.urdomain.ch07.package2;
import com.urdomain.ch07.package1.A;

public class D extends A {
	public D() {
		super();				// (o)
		this.field = "value";	// (o)
		this.method();			// (o)
	}
}

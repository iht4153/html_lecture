package com.urdomain.ch07;

public class Child1 extends Parent1 {
	@Override
	public void method2() {
		System.out.println("Child-method2()");
	}
}

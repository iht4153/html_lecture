package com.urdomain.ch07;

public class Child2 extends Parent2 {
	public String field2;
	
	public void method3() {
		System.out.println("Child-method3()");
	}
}

package com.urdomain.ch07;

public final class Member {

}

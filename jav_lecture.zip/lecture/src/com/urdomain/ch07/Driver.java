package com.urdomain.ch07;

public class Driver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}

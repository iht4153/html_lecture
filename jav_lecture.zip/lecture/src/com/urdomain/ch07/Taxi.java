package com.urdomain.ch07;

public class Taxi extends Vehicle {
	@Override
	public void run() {
		System.out.println("�ýð� �޸��ϴ�.");
	}
}

package com.urdomain.ch07;

public class Parent3 {
}

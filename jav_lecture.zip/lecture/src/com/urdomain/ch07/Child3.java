package com.urdomain.ch07;

public class Child3 extends Parent3 {
}

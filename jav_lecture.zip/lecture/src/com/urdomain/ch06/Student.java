package com.urdomain.ch06;

public class Student {
}
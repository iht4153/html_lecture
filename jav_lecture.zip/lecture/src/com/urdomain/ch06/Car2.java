package com.urdomain.ch06;

public class Car2 {
	String color;
	int cc;

	// ������
	Car2(String color, int cc) {
		this.color = color;
		this.cc = cc;
	}

}
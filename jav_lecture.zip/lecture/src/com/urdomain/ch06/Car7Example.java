package com.urdomain.ch06;

public class Car7Example {
	public static void main(String[] args) {
		Car7 myCar = new Car7("������");
		Car7 yourCar = new Car7("����");
		
		myCar.run();
		yourCar.run();
	}

}

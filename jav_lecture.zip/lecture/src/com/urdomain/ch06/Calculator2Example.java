package com.urdomain.ch06;

public class Calculator2Example {
	public static void main(String[] args) {
		Calculator2 myCalc = new Calculator2();
		myCalc.execute();
	}
}

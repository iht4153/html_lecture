package com.urdomain.ch06;

public class Television {
	static String company = "Samsun";
	static String model = "LCD";
	static String info;
	
	static {
		info = company + "-" + model;
	}
}

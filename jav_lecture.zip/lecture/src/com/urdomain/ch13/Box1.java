package com.urdomain.ch13;

public class Box1 {
	private Object object;
	public void set(Object object) { this.object = object; }
	public Object get() { return object; }
}
